package com.lxisoft.hackathon;

import com.lxisoft.hackathon.quiz.IQuestion;
import com.lxisoft.hackathon.quiz.MultipleChoiceQuestion;
import com.lxisoft.hackathon.quiz.SocialTaskQuestion;
import com.lxisoft.hackathon.quiz.TrueOrFalseQuestion;

public class TDD {
	
    public static void main(String[] args) throws Exception {
	
	String[] options = {"aa" , "bb", "cc" , "dd"};
	IQuestion quiz[] = { new MultipleChoiceQuestion("kk", options , 1), 
                         new TrueOrFalseQuestion("hy", false),
                         new SocialTaskQuestion("helo")   } ;
    
    System.out.println("Welcome to quiz")                      ;

    for( IQuestion q : quiz)
    {
        q.displayQuestion();
    }
    System.out.println("Thank you")                      ;


}
}
