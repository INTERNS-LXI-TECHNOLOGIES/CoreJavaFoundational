
package com.lxisoft.hackathon.quiz;

public abstract class Question implements IQuestion{
    static int totalScores ;


    // Implement  int calculateAverageScores() 

    private String questionText;
	
	public Question(String questionText, String[] options, int answerChoice) {
        
    }
	
	public Question(String questionText, boolean answer) {
        
    }

    public Question(String questionText) {
        this.questionText = questionText;
    }

    public String getQuestionText() {
        return questionText;
    }
	
	@Override
	public void displayQuestion(){
		System.out.println("hy");
	}

    public abstract void ask();
}
