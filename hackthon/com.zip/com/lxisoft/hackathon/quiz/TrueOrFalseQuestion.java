
package com.lxisoft.hackathon.quiz;

import com.lxisoft.hackathon.exception.SeriouslyWrongException;

public class TrueOrFalseQuestion extends Question {

    boolean answer ;

    public TrueOrFalseQuestion(String questionText, boolean answer) throws Exception {
        super(questionText);
        if (questionText == null){
            throw new SeriouslyWrongException("message");
        }
    }

    @Override
    public void ask() {
        System.out.println(getQuestionText() + " (True/False)");
        // use scanner to collect the answer
    }
	
	
}
